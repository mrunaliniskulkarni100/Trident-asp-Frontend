﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Configuration;

namespace Trident_Project
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_Click(object sender, EventArgs e)
        {
                   SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnect"].ConnectionString);

            conn.Open();
            string password = Request.Form["password"];
            string username = Request.Form["username"];
            string insertQuery = "SELECT phonenumber, firstname, email, username, password, address, gen_model, gen_id FROM [user] WHERE (username = @username and password = @password)";
            SqlCommand cmd = new SqlCommand(insertQuery,conn);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@username", username);
        SqlDataReader sdr = cmd.ExecuteReader();  
        if(sdr.Read())  
        {  
           
            Response.Redirect("home_admin.aspx");
        }  
        else  
        {  
            Response.Write("UserId & Password Is not correct Try again..!!");  
  
        }  
            conn.Close();  
        } 
        
    }
}