﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Configuration;

namespace Trident_Project
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {     
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnect"].ConnectionString);

            conn.Open();
            string gen_id = Request.QueryString["genid"]; 


            string insertQuery = "SELECT phonenumber, firstname, email, address, gen_model FROM [user] WHERE (gen_id = @gen_id)";
            SqlCommand cmd = new SqlCommand(insertQuery, conn);
            cmd.Parameters.AddWithValue("@gen_id", gen_id);

            SqlDataReader sdr = cmd.ExecuteReader();
            if (sdr.Read())
            {
               
                
                name=sdr["firstname"].ToString();//your cloumn name;
                add1=sdr["address"].ToString(); 
                model=sdr["gen_model"].ToString();
                email=sdr["email"].ToString();
                contact=sdr["phonenumber"].ToString();
               
            }
            else
            {
                Response.Write("No model Id Found!!");

            }
            conn.Close();
        }



        public string name { get; set; }

        public string add1 { get; set; }
        public string gen_id { get; set; } 

        public string model { get; set; }

        public string email { get; set; }

        public string contact { get; set; }
    }
         
        
}
