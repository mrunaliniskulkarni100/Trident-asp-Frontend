﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Text;
using System.IO;
using System.Configuration;


namespace Trident_Project
{
    public partial class WebForm7 : System.Web.UI.Page
    {
               
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void button_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnect"].ConnectionString);
         
            conn.Open();
          string email = Request.Form["email"];
            string password = Request.Form["password"];
            string phonenumber = Request.Form["phonenumber"];
            string address = Request.Form["address"];
            string gen_model = Request.Form["gen_model"];
            string gen_id = Request.Form["gen_id"];
            string firstname = Request.Form["firstname"];
            string username = Request.Form["username"];
           // string insertQuery = "insert into [user] (phonenumber, firstname, email, username, password, address, gen_model, gen_id) values (" + phonenumber + "," + firstname + "," + email + "," + username + "," + password + "," + address + "," + gen_model + "," + gen_id + ")";
               //string insertQuery = "insert into user values ('7218','varad','varad','vv','123','asasf','1q','a1')";
            string insertQuery = "insert into [user] (phonenumber, firstname, email, username, password, address, gen_model, gen_id) values (@phonenumber,@firstname,@email,@username,@password,@address,@gen_model,@gen_id)";
               
            SqlCommand cmd = new SqlCommand(insertQuery, conn);
               cmd.Parameters.AddWithValue("@firstname", firstname);
               cmd.Parameters.AddWithValue("@password", password);
               cmd.Parameters.AddWithValue("@email", email);
               cmd.Parameters.AddWithValue("@phonenumber", phonenumber);
               cmd.Parameters.AddWithValue("@username", username);
               cmd.Parameters.AddWithValue("@address", address);
               cmd.Parameters.AddWithValue("@gen_model", gen_model);
               cmd.Parameters.AddWithValue("@gen_id", gen_id);
               cmd.ExecuteNonQuery();
               
              
                
               // Response.Redirect("about_us.aspx?Username="+username);
                
                conn.Close();
            
         }
      
    }
}